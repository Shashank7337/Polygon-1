
    export const nftAddress = "0xE59F3299AeFD2bB0708d993AeCFbd16c0c10cfC7"
    